/*module.exports = {
    devServer: {
        disableHostCheck: true,
        port: 8099,
        host: '39.107.242.34'
    }
}*/;