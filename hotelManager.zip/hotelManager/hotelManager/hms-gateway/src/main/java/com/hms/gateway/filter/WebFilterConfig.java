//package com.hms.gateway.filter;
//
//
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//public class WebFilterConfig {
//    @Bean
//    public FilterRegistrationBean webCrossFilterRegistration() {
//        FilterRegistrationBean registration = new FilterRegistrationBean();
//        registration.setFilter(new WebCrossFilter());
//        registration.addUrlPatterns("/**");
//        registration.addInitParameter("paramName", "paramValue");
//        registration.setName("webCrossFilter");
//        return registration;
//    }
//}
