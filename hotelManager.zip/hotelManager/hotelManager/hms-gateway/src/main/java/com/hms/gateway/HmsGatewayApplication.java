package com.hms.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.filter.LoadBalancerClientFilter;

/**
 * API网关
 */
@EnableDiscoveryClient
@SpringBootApplication
public class HmsGatewayApplication {

    public static void main(String[] args) {
        System.out.println("================================================== 开始启动 gateway网关服务 =============================================================");

        SpringApplication.run(HmsGatewayApplication.class, args);
        System.out.println("================================================== gateway网关服务 启动成功 =============================================================");
    }
}
