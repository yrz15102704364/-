# springcloud微服务项目开发模板

#### 介绍
springcloud开发模板

#### 软件架构
软件架构说明
基于尚医通的架构模板

xxx-parent：根目录，管理子模块  

&emsp;common：公共模块父节点
        
&emsp;&emsp;common-util：工具类模块，所有模块都可以依赖于它  

&emsp;&emsp;service-util：service服务的工具包，包含service服务的公共配置类，所有service模块依赖于它  

&emsp;server-gateway：服务网关  

&emsp;model：实体类模块  

&emsp;service：api接口服务父节点  

&emsp;&emsp;service-xx：xxapi接口服务  

&emsp;service-client：feign服务调用父节点  

&emsp;&emsp;service-xx-client：xxapi接口



