package com.hms.reserve.rpc;

import com.hms.pojo.po.Room;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/18:32
 * @Descriptioin
 */
@FeignClient(name = "hms-service-reserve")
public interface RoomRpcApi {

    @RequestMapping("rpc/getById")
    Room getById(String id);
}
