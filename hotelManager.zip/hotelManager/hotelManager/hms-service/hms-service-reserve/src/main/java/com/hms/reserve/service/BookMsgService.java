package com.hms.reserve.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hms.pojo.po.BookMsg;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;


@Service
public interface BookMsgService extends IService<BookMsg> {


    List<BookMsg> getBookMsgByIdCard(String idCard);

    List<BookMsg> getBookMsgByTime(Timestamp fromTime, Timestamp toTime);

    boolean removeByIdCard(String idCard);

    boolean removeByResultRoom(String id);

    List<BookMsg> getBookMsgByTime1(Timestamp fromTimeT, Timestamp toTimeT);
}
