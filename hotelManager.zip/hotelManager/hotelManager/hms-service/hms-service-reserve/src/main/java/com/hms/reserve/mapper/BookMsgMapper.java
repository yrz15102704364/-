package com.hms.reserve.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hms.pojo.po.BookMsg;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;


@Mapper
@Repository
public interface BookMsgMapper extends BaseMapper<BookMsg> {

    List<BookMsg> getBookMsgByIdCard(String idCard);
    List<BookMsg> getBookMsgByTime(@Param("fromTime")Timestamp fromTime, @Param("toTime")Timestamp toTime);
    boolean removeByIdCard(String idCard);
    boolean removeByResultRoom(String id);
    List<BookMsg> getBookMsgByTime1(@Param("fromTimeT") Timestamp fromTimeT, @Param("toTimeT") Timestamp toTimeT);


}
