package com.hms.reserve.rpc;

import com.hms.pojo.po.Guest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/18:31
 * @Descriptioin
 */
@FeignClient(name = "hms-service-guestAndRoom")
public interface GuestRpcApi {

    @RequestMapping("guestAndRoom/rpc/saveOrUpdate")
    boolean saveOrUpdate(Guest guest);
}
