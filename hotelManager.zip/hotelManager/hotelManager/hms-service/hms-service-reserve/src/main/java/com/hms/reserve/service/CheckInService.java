package com.hms.reserve.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hms.pojo.po.CheckIn;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;


@Service
public interface CheckInService extends IService<CheckIn> {

    List<CheckIn> getValidCheckIns(Timestamp fromTime, Timestamp toTime);

    int getNum(String roomId);

    List<CheckIn> getByIdCard(String idCard);

    boolean removeByIdCard(String idCard);

    boolean removeByRoomId(String id);

    List<CheckIn> getValidCheckIns1(Timestamp fromTimeT, Timestamp toTimeT);
}
