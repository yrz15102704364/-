package com.hms.reserve.rpc;

import com.hms.pojo.vo.Response;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/14:37
 * @Descriptioin
 */
@FeignClient(name = "hms-service-admin")
public interface BackAdminRpcApi {

    // 通过id获取管理员信息
    @GetMapping("admin/rpc/getBackgroundById")
    Response getById(String id);
}
