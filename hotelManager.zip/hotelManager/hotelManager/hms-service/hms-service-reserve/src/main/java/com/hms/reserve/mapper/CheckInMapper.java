package com.hms.reserve.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hms.pojo.po.CheckIn;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;


@Mapper
@Repository
public interface CheckInMapper extends BaseMapper<CheckIn> {
    List<CheckIn> getValidCheckIns(@Param("fromTime") Timestamp fromTime, @Param("toTime")Timestamp toTime);

    int getNum(String roomId);

    List<CheckIn> getByIdCard(String idCard);
    boolean removeByIdCard(String idCard);
    boolean removeByRoomId(String id);
    List<CheckIn> getValidCheckIns1(@Param("fromTimeT") Timestamp fromTimeT, @Param("toTimeT")Timestamp toTimeT);
}
