package com.hms.admin.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hms.admin.mapper.FrontMapper;
import com.hms.admin.service.FrontService;
import com.hms.pojo.po.Front;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class FrontServiceImpl extends ServiceImpl<FrontMapper, Front> implements FrontService {
    @Autowired
    private FrontMapper frontMapper;
}
