package com.hms.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hms.pojo.po.Background;
import org.springframework.stereotype.Service;


@Service
public interface BackgroundService extends IService<Background> {
}
