package com.hms.admin.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hms.admin.mapper.BackgroundMapper;
import com.hms.admin.service.BackgroundService;
import com.hms.pojo.po.Background;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BackgroundServiceImpl extends ServiceImpl<BackgroundMapper, Background> implements BackgroundService {
    @Autowired
    private BackgroundMapper backgroundMapper;
}
