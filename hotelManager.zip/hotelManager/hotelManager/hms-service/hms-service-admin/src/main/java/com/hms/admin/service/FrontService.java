package com.hms.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hms.pojo.po.Front;
import org.springframework.stereotype.Service;


@Service
public interface FrontService extends IService<Front> {

}
