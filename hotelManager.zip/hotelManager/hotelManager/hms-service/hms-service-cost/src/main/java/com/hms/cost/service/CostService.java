package com.hms.cost.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hms.pojo.po.Cost;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface CostService extends IService<Cost> {

    List<Cost> getCostByRoomId(String roomId);

    boolean settleCostByRoomId(String roomId);

    boolean removeByRoomId(String roomId);

    int getNotCostNum(String roomId);

    boolean removeByCostTypeId(Integer id);
}
