package com.hms.cost.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hms.pojo.po.CostType;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface CostTypeMapper extends BaseMapper<CostType> {
    List<CostType> getCostTypeByName(String name);

    List<CostType> getAllCostType();

    boolean removeByName(String name);
}
