package com.hms.cost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/13:53
 * @Descriptioin
 */
@EnableDiscoveryClient
@SpringBootApplication
@EnableFeignClients
@ComponentScan(basePackages  = {"com.hms.utils", "com.hms.cost"})
public class CostServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CostServiceApplication.class, args);

        System.out.println("================================================== cost服务 启动成功 =============================================================");
    }
}
