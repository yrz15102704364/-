package com.hms.cost.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hms.pojo.po.Cost;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface CostMapper extends BaseMapper<Cost> {
    List<Cost> getCostByRoomId(String roomId);
    boolean settleCostByRoomId(String roomId);
    boolean removeByRoomId(String roomId);
    int getNotCostNum(String roomId);
    boolean removeByCostTypeId(Integer id);
}
