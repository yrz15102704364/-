package com.hms.cost.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hms.cost.mapper.CostTypeMapper;
import com.hms.cost.service.CostTypeService;
import com.hms.pojo.po.CostType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CostTypeServiceImpl extends ServiceImpl<CostTypeMapper, CostType> implements CostTypeService {
    @Autowired
    private CostTypeMapper costTypeMapper;
    @Override
    public List<CostType> getCostTypeByName(String name) {
        return costTypeMapper.getCostTypeByName(name);
    }

    @Override
    public List<CostType> getAllCostType() {
        return costTypeMapper.getAllCostType();
    }

    @Override
    public boolean removeByName(String name) {
        return costTypeMapper.removeByName(name);
    }
}
