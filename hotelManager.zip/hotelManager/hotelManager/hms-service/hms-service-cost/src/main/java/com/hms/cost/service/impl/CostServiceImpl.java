package com.hms.cost.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hms.cost.mapper.CostMapper;
import com.hms.cost.service.CostService;
import com.hms.pojo.po.Cost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CostServiceImpl extends ServiceImpl<CostMapper, Cost> implements CostService {
    @Autowired
    private CostMapper costMapper;

    @Override
    public List<Cost> getCostByRoomId(String roomId) {
        return costMapper.getCostByRoomId(roomId);
    }

    @Override
    public boolean settleCostByRoomId(String roomId) {
        return costMapper.settleCostByRoomId(roomId);
    }

    @Override
    public boolean removeByRoomId(String roomId) {
        return costMapper.removeByRoomId(roomId);
    }

    @Override
    public int getNotCostNum(String roomId) {
        return costMapper.getNotCostNum(roomId);
    }

    @Override
    public boolean removeByCostTypeId(Integer id) {
        return costMapper.removeByCostTypeId(id);
    }
}
