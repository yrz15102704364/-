package com.hms.guestAndRoom.rpc;

import com.hms.pojo.po.CostType;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/18:24
 * @Descriptioin
 */
@FeignClient(name = "hms-service-cost")
public interface CostTypeRpcApi {


    @RequestMapping("cost/rpc/removeByName")
    boolean removeByName(String name);

    @RequestMapping("cost/rpc/saveOrUpdateCostType")
    boolean saveOrUpdate(CostType costType);

    @RequestMapping("cost/rpc/getCostTypeByName")
    List<CostType> getCostTypeByName(String name);

}
