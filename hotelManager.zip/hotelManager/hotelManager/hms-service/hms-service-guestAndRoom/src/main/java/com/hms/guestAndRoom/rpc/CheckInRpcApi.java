package com.hms.guestAndRoom.rpc;

import com.hms.pojo.po.CheckIn;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Timestamp;
import java.util.List;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/18:07
 * @Descriptioin
 */
@FeignClient(name = "hms-service-reserve")
public interface CheckInRpcApi {

    @RequestMapping("reserve/rpc/removeByIdCardCheckIn")
    boolean removeByIdCard(String idCard);

    @RequestMapping("reserve/rpc/getByIdCard")
    List<CheckIn> getByIdCard(String idCard);

    @RequestMapping("reserve/rpc/removeByRoomId")
    boolean removeByRoomId(String id);

    @RequestMapping("reserve/rpc/getValidCheckIns")
    List<CheckIn> getValidCheckIns(@RequestParam("fromTime")Long fromTime,@RequestParam("toTime") Long toTime);

    @RequestMapping("reserve/rpc/getValidCheckIns1")
    List<CheckIn> getValidCheckIns1(@RequestParam("fromTimeT")Long fromTimeT, @RequestParam("toTimeT")Long toTimeT);

}
