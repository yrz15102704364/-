package com.hms.guestAndRoom.rpc;

import com.hms.pojo.po.Cost;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/15:39
 * @Descriptioin
 */
@FeignClient(name = "hms-service-cost")
public interface CostRpcApi {

    @RequestMapping("cost/rpc/saveOrUpdateCost")
    boolean saveOrUpdate(Cost cost);

    @RequestMapping("cost/rpc/getNotCostNum")
    int getNotCostNum(String roomId);

    @RequestMapping("cost/rpc/settleCostByRoomId")
    boolean settleCostByRoomId(String roomId);

    @RequestMapping("cost/rpc/removeByRoomId")
    boolean removeByRoomId(String roomId);
}
