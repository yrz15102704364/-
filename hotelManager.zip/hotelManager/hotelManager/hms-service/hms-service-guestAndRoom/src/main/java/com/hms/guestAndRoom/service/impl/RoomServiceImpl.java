package com.hms.guestAndRoom.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hms.guestAndRoom.mapper.RoomMapper;
import com.hms.guestAndRoom.service.RoomService;
import com.hms.pojo.po.Room;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class RoomServiceImpl extends ServiceImpl<RoomMapper, Room> implements RoomService {
    @Autowired
    private RoomMapper roomMapper;

    @Override
    public List<Room> getRoomsByType(String rank) {
        return roomMapper.getRoomsByType(rank);
    }
}
