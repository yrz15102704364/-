package com.hms.guestAndRoom.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hms.guestAndRoom.mapper.GuestMapper;
import com.hms.guestAndRoom.service.GuestService;
import com.hms.pojo.po.Guest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class GuestServiceImpl extends ServiceImpl<GuestMapper, Guest> implements GuestService {

    @Autowired
    GuestMapper guestMapper;

    @Override
    public List<Guest> getByIdCard(String idCard) {
        return guestMapper.getByIdCard(idCard);
    }

    @Override
    public List<Guest> getByContact(String contact) {
        return guestMapper.getByContact(contact);
    }

    @Override
    public List<Guest> getByName(String name) {
        return guestMapper.getByName(name);
    }
}
