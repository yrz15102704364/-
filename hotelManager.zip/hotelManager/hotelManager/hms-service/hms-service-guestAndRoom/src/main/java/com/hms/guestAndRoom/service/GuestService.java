package com.hms.guestAndRoom.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hms.pojo.po.Guest;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface GuestService extends IService<Guest> {

    List<Guest> getByIdCard(String idCard);

    List<Guest> getByContact(String contact);

    List<Guest> getByName(String name);
}
