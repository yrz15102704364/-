package com.hms.guestAndRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hms.pojo.po.Guest;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface GuestMapper extends BaseMapper<Guest> {
    List<Guest> getByIdCard(String idCard);

    List<Guest> getByContact(String contact);

    List<Guest> getByName(String name);
}
