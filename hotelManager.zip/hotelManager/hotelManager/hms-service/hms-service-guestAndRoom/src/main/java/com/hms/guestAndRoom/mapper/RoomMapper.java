package com.hms.guestAndRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hms.pojo.po.Room;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface RoomMapper extends BaseMapper<Room> {
    List<Room> getRoomsByType(String rank);
}
