package com.hms.guestAndRoom.rpc;

import com.hms.pojo.po.BookMsg;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Timestamp;
import java.util.List;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/18:00
 * @Descriptioin
 */
@FeignClient(name = "hms-service-reserve")
public interface BookMsgRpcApi {

    @RequestMapping("reserve/rpc/getBookMsgByIdCard")
    List<BookMsg> getBookMsgByIdCard(String idCard);

    @RequestMapping("reserve/rpc/removeByIdCardBook")
    boolean removeByIdCard(String idCard);

    @RequestMapping("reserve/rpc/getBookMsgByTime")
    List<BookMsg> getBookMsgByTime(@RequestParam("fromTime")Long fromTime, @RequestParam("toTime")Long toTime);

    @RequestMapping("reserve/rpc/getBookMsgByTime1")
    List<BookMsg> getBookMsgByTime1(@RequestParam("fromTimeT")Long fromTimeT, @RequestParam("toTimeT")Long toTimeT);

    @RequestMapping("reserve/rpc/removeByResultRoom")
    boolean removeByResultRoom(String id);
}
