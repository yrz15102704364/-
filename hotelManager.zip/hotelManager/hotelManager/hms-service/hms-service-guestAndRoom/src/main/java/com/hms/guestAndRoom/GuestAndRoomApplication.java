package com.hms.guestAndRoom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * @Auther: yrz
 * @Date: 2022/04/15/15:57
 * @Descriptioin
 */
@EnableDiscoveryClient
@SpringBootApplication
@EnableFeignClients
@ComponentScan(basePackages  = {"com.hms.utils", "com.hms.guestAndRoom"})
public class GuestAndRoomApplication {

    public static void main(String[] args) {
        SpringApplication.run(GuestAndRoomApplication.class, args);

        System.out.println("================================================== guestAndRoom服务 启动成功 =============================================================");
    }
}
