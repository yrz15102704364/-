package com.hms.pojo.po;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class CostType extends Model<CostType> {


    /**
     * 消费类型的id
     */
    private Integer id;

    /**
     * 消费项目的名称
     */
    private String name;

    /**
     * 金额
     */
    private Double money;



}
